get_pass <- function(prompt = "Password: ") {
  askpass::askpass(prompt = prompt)
}
