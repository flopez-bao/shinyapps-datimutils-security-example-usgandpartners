library(testthat)
library(keyring)

test_check("keyring")
