library(httptest)
play233 <- list(base_url = "https://play.dhis2.org/2.33/",
                handle = httr::handle("https://play.dhis2.org/2.33/"))
play235 <- list(base_url = "https://play.dhis2.org/2.33.5/",
                handle = httr::handle("https://play.dhis2.org/2.33.5/"))
play234 <- list(base_url = "https://play.dhis2.org/2.34/",
                handle = httr::handle("https://play.dhis2.org/2.34/"))
play2335 <- list(base_url = "https://play.dhis2.org/2.33.5/",
                handle = httr::handle("https://play.dhis2.org/2.33.5/"))
play2341 <- list(base_url = "https://play.dhis2.org/2.34.1/",
                handle = httr::handle("https://play.dhis2.org/2.34.1/"))
