library(testthat)
library(datimutils)
test_check("datimutils")
