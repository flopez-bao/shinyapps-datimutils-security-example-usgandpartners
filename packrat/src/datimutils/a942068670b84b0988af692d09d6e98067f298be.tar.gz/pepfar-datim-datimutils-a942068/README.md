# DATIMUtils
**Repo Owner:** Scott Jackson [@jacksonsj](https://github.com/jacksonsj)


To install:

```R
devtools::install_github(repo = "https://github.com/pepfar-datim/datimutils.git", ref = "master")
```

For bug reports or feature requests:

[GitHub ticket](https://github.com/pepfar-datim/datimutils/issues/new), or via [DATIM Support](https://datim.zendesk.com) (DATIM users only).
